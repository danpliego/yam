<div class="page text-light py-5 text-center text-primary">
  <div class="container">
    <div class="py-5">    
      <h1 class="text-primary">TULUM 2018</h1>
      <div class="embed-responsive embed-responsive-16by9 my-5">
        <iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/u7-20aHePeU?autoplay=1&mute=1&rel=0&showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen class="embed-responsive-item"></iframe>
      </div>
    </div>
    <div class="py-5">
      <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/flyer.png" class="img-fluid" />
    </div>
    <div class="py-5">
      <h2 class="text-primary">VENUE</h2>
      <div class="row justify-content-center py-5">
        <div class="col-md-10">
          <p class="text-primary">
            Located at La Valise Tulum you will find yourself in a slice of paradise nested between the luxuriant jungle and the pearl white sand beaches of the Caribbean.
          </p>
          <p class="text-primary">
            This is the place to enjoy beauty, peacefulness and uniqueness. A place where the magic of Tulum is preserved on a private beachfront villa and bungalows, bit added an ode to Mexican art and craft, wood in all its forms, offering comfort, surprise and daydream; this is Robinson Crusoe meets Crafted Museum-curated villa.
          </p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
        </div>
        <div class="col">
          <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
        </div>
        <div class="col">
          <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
        </div>
        <div class="col">
          <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
        </div>
        <div class="col">
          <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
        </div>
      </div>
    </div>
    <div class="py-5">
      <h2 class="text-primary">LINEUP</h2>
      <div class="row justify-content-center py-5">
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>SABO</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>SATORI</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>MENDRIX</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>ISI AUDI</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>CRIS KAI</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>KUUMBA</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>MORDEJAI</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
        <div class="col-md-4 mb-4 p-4">
          <a href="#">
            <h4>MECA MECA</h4>
            <img src="<?php echo get_bloginfo('template_url') ?>/assets/images/venue/1.png" class="img-fluid" />
          </a>
        </div>
      </div>
    </div>
    @php the_content() @endphp
  </div>
</div>
