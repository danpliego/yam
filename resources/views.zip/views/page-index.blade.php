{{--
  Template Name: Index
--}}

@extends('layouts.app')

@section('content')
  @include('partials.page-index')
@endsection
